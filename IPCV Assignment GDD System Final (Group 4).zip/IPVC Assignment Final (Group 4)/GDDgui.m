function varargout = GDDgui(varargin)
% GDDGUI MATLAB code for GDDgui.fig
%      GDDGUI, by itself, creates a new GDDGUI or raises the existing
%      singleton*.
%
%      H = GDDGUI returns the handle to a new GDDGUI or the handle to
%      the existing singleton*.
%
%      GDDGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GDDGUI.M with the given input arguments.
%
%      GDDGUI('Property','Value',...) creates a new GDDGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GDDgui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GDDgui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GDDgui

% Last Modified by GUIDE v2.5 30-Jul-2022 05:50:34

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GDDgui_OpeningFcn, ...
                   'gui_OutputFcn',  @GDDgui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

% End initialization code - DO NOT EDIT


% --- Executes just before GDDgui is made visible.
function GDDgui_OpeningFcn(hObject, ~, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GDDgui (see VARARGIN)

% Choose default command line output for GDDgui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes GDDgui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GDDgui_OutputFcn(~, ~, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



% --- Executes on button press in BrowsePB.
% Browse Button Function
function BrowsePB_Callback(~, ~, handles)  
% handles    structure with handles and user data (see GUIDATA)

global img;                        % Declaring global variable so the image can be used in another function
[Filename, Pathname]=uigetfile('*.jpg','Upload Glove Image'); % Browsing Image File on user's machine
name=strcat(Pathname,Filename);

img=imread(name);
set(handles.edit1, 'string',name); % Displaying File Path in appropriate textbox
axes(handles.axes1);               % Displaying image in appropriate axes
imshow(img);





% --- Executes on button press in ResetPB.
% Reset Button Function
function ResetPB_Callback(~, ~, handles)
% handles    structure with handles and user data (see GUIDATA)

% clears all axes, all global variables and the file path textbox
arrayfun(@cla,findall(0,'type','axes'));
set(handles.edit1,'string','');
clear global img;
clear global comp1;
clear global comp2;



% --- Executes on button press in ExitPB.
% Exit Button Function
function ExitPB_Callback(~, ~, handles)
% handles    structure with handles and user data (see GUIDATA)

% Dialogue box for user exit confirmation
fig = uifigure;
selection = uiconfirm(fig,'Close GDD System?','Confirm Close',...
                        'Icon','warning');

if (selection=="OK") % If user confirms exit
    % closes dialogue box, clears all axes, all global variables and the file path textbox
    close(fig);
    arrayfun(@cla,findall(0,'type','axes'));
    set(handles.edit1,'string','');
    clear global img;
    clear global comp1;
    clear global comp2;
    close(GDDgui);              % Closes GDD System

else
    close(fig);        % If user cancels exit, then dialogue box closes and system stays open
end




% --- Executes on button press in DetectPB.
% Detect Button Function
function DetectPB_Callback(~, ~, handles)
% handles    structure with handles and user data (see GUIDATA)

global img;                         % Using global variable
global comp2;                       % Declaring global variable to be used in another function
global comp1;                       % Declaring global variable to be used in another function

gray = rgb2gray(img);                 % Grayscale Image
bw = im2bw(gray,graythresh(gray));    % Black and White Image
comp2=bw;
axes(handles.axes4);                  % Display Image in appropriate axes
imshow(gray);
axes(handles.axes3);                  % Display Image in appropriate axes 
imshow(bw);
bw2 = bwmorph(bw,'remove');           % Outline Glove and Defects


se = strel('square', 2);
edge2 = imdilate(bw2, se);           % Dilate Image
axes(handles.axes5);                % Display Image in appropriate axes
imshow(edge2);
fill = imfill(edge2,'holes');       % Fill In Defects
comp1=fill;
axes(handles.axes6);                % Display Image in appropriate axes
imshow(fill);


[label, num] = bwlabel(bw2);   % Getting Label matrix and number of connected objects
disp(num);

props = regionprops(label);    % measure properties for labelled regions

box = [props.BoundingBox];     % Getting position and size of labelled regions

box = reshape(box,4,[]);     % Reshape box (4-by-[] matrix) [] = empty numeric array
axes(handles.axes8);         % Display Image in appropriate axes
imshow(img);
hold on;                     % Retain Image and Add Rectangle Above

for cnt=2:num
rectangle('position',box(:,cnt),'edgecolor','r');       % Show Red Rectangle Around All Defects Found
end

f = msgbox("Detection Scan Completed!", "Completion","help");   % Inform User of Completion
imshow(f);



% Textbox to display file path of selected image
function edit1_Callback(~, ~, ~)





% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, ~, ~)
% hObject    handle to edit1 (see GCBO)

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in CompareToggle.
% Compare Button Function
function CompareToggle_Callback(hObject, ~, handles)
% hObject    handle to CompareToggle (see GCBO)
% handles    structure with handles and user data (see GUIDATA)

% Using global variables for comparison
global comp2;
global comp1;

comp=get(hObject,'Value');   % get(hObject,'Value') returns toggle state of CompareToggle
if (comp==1)            % User clicks toggle button on
    axes(handles.axes8); % Display Image in appropriate axes
    imshow(comp2);
else                    % User click toggle button off
    axes(handles.axes8);  % Display Image in appropriate axes
    imshow(comp1);
end
