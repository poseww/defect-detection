function varargout = GDDgui(varargin)
% GDDGUI Kode MATLAB untuk GDDgui.fig

% Mulai kode inisialisasi - JANGAN DIEDIT

gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GDDgui_OpeningFcn, ...
                   'gui_OutputFcn',  @GDDgui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end

% Akhir kode inisialisasi - JANGAN DIEDIT

% --- Eksekusi sebelum GDDgui ditampilkan
function GDDgui_OpeningFcn(hObject, ~, handles, varargin)
handles.output = hObject;
guidata(hObject, handles);

% --- Mengembalikan output ke command line
function varargout = GDDgui_OutputFcn(~, ~, handles) 
varargout{1} = handles.output;

% --- Tombol Browse untuk memilih gambar sarung tangan
function BrowsePB_Callback(~, ~, handles)  
global gambar;
[namaFile, lokasiFile] = uigetfile('*.jpg','Unggah Gambar Sarung Tangan');
pathLengkap = strcat(lokasiFile, namaFile);

gambar = imread(pathLengkap);
set(handles.edit1, 'string', pathLengkap);
axes(handles.axes1);
imshow(gambar);

% --- Tombol Reset untuk menghapus gambar dan variabel global
function ResetPB_Callback(~, ~, handles)
arrayfun(@cla,findall(0,'type','axes'));
set(handles.edit1,'string','');
clear global gambar;
clear global komponen1;
clear global komponen2;

% --- Tombol Exit untuk keluar dari aplikasi
function ExitPB_Callback(~, ~, handles)
fig = uifigure;
konfirmasi = uiconfirm(fig,'Tutup Sistem GDD?','Konfirmasi Keluar', 'Icon','warning');

if (konfirmasi == "OK")
    close(fig);
    arrayfun(@cla,findall(0,'type','axes'));
    set(handles.edit1,'string','');
    clear global gambar;
    clear global komponen1;
    clear global komponen2;
    close(GDDgui);
else
    close(fig);
end

% --- Tombol Deteksi untuk melakukan deteksi cacat pada gambar
function DetectPB_Callback(~, ~, handles)
global gambar;
global komponen2;
global komponen1;

abuAbu = rgb2gray(gambar);
hitamPutih = im2bw(abuAbu, graythresh(abuAbu));
komponen2 = hitamPutih;
axes(handles.axes4);
imshow(abuAbu);
axes(handles.axes3);
imshow(hitamPutih);

garisTepi = bwmorph(hitamPutih, 'remove');
se = strel('square', 2);
dilatasi = imdilate(garisTepi, se);
axes(handles.axes5);
imshow(dilatasi);

terisi = imfill(dilatasi, 'holes');
komponen1 = terisi;
axes(handles.axes6);
imshow(terisi);

[labelObjek, jumlahObjek] = bwlabel(garisTepi);
props = regionprops(labelObjek);
kotakPendeteksi = reshape([props.BoundingBox], 4, []);
axes(handles.axes8);
imshow(gambar);
hold on;

for hitung = 2:jumlahObjek
    rectangle('position', kotakPendeteksi(:, hitung), 'edgecolor', 'r');
end

notifikasi = msgbox("Pendeteksian Selesai!", "Selesai", "help");
imshow(notifikasi);

% --- Tombol Toggle untuk membandingkan gambar hasil deteksi
function CompareToggle_Callback(hObject, ~, handles)
global komponen2;
global komponen1;

perbandingan = get(hObject, 'Value');
if (perbandingan == 1)
    axes(handles.axes8);
    imshow(komponen2);
else
    axes(handles.axes8);
    imshow(komponen1);
end
